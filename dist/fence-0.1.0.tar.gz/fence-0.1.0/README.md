# 🤺 Fence

No, not that kind of fence. The once with the interlinked pieces of metal. Like a chain fence? 

Why? Well, I got fed up with LangChain being so bloated, and I wanted to make a quick little repo
that covers some of the basic functionality of LangChain, but in a much smaller package. Also, if
we're calling the things Chains now, then a single component should be a Link (I don't care that it's
confusing, it's a good name). Extrapolating the concept gives us Fence. I don't care that the naming sucks,
it amuses me.

## What is it?

Fence is a simple, lightweight library for LLM communication.